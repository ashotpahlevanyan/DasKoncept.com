var scene = document.getElementById('js-scene2');
var parallax = new Parallax(scene);