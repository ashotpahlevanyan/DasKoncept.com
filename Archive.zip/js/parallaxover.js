var scene = document.getElementById('js-scene');
var parallax = new Parallax(scene);