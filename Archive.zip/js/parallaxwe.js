var scene = document.getElementById('js-scene3');
var parallax = new Parallax(scene);