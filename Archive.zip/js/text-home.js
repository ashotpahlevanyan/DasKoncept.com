var opac1 = anime({
	targets: '.letter',
	opacity: 1,
	delay: function(el, index) {
		return index * 1000;
	},
});

var opac2 = anime({
	targets: '.letter2',
	opacity: 1,
	delay: function(el, index) {
		return index * 1200;
	},
});

var opac3 = anime({
	targets: '.letter3',
	opacity: 1,
	delay: function(el, index) {
		return index * 2300;
	},
});

var opac4 = anime({
	targets: '.letter4',
	opacity: 1,
	delay: function(el, index) {
		return index * 1200;
	},
});

var opac5 = anime({
	targets: '.letter5',
	opacity: 1,
	delay: function(el, index) {
		return index * 1900;
	},
});

var opac6 = anime({
	targets: '.letter6',
	opacity: 1,
	delay: function(el, index) {
		return index * 1700;
	},
});